# DOGUI Web

Landing page estatica para DOGUI, enfocada en servicios de ciberseguridad, automatizacion y consultoria SPEI/SPID.

## Contenido

- Hero comercial con imagen de operaciones de ciberseguridad.
- Secciones de servicios: SOC/MDR, pentesting, Blue Team, respuesta a incidentes, GRC y capacitacion.
- Productos/plataformas: CTI, EDR, SIEM, dark web, GRC y SOAR.
- Seccion especializada para consultoria SPEI/SPID.
- Paquetes comerciales y formulario de contacto con `mailto:`.

## Uso local

Abre `index.html` directamente en el navegador.

## Archivos principales

- `index.html`
- `styles.css`
- `script.js`
- `assets/dogui-hero.png`

## Pendientes de branding

- Sustituir el isotipo temporal por logotipo oficial.
- Cambiar correo, telefono y datos legales reales.
- Ajustar paleta final si DOGUI ya tiene manual de marca.
